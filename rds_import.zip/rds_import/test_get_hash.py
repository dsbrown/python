#!/usr/local/bin/python
# -*- coding: utf-8 -*-

d={'whale':'blue','ray':'manta','beetle':'lady bug','dog':'cocker'}
search_fields = ('whale','frog','ray','beetle','bug')
for i in search_fields:
    if d.get(i):
        print "found "+d[i]+" using key "+i
